const s="/assets/risk management-2b060241.jpg";export{s as r};
